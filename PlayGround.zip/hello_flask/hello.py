from os import times
from flask import Flask , render_template  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"
@app.route('/')         
def hello_world():
    return "hello"  # Return the string 'Hello World!' as a response

@app.route('/play')
def playGround1():
    return render_template('playGround1.html')

@app.route('/play/<num>')          
def playGround2(num):
    return render_template('playGround2.html', times=int(num)) 
    

@app.route('/play/<num>/<color>')
def playGround3(num,color):
    return render_template('playGround3.html', times=int(num), boxColor=color)

# @app.route('/<int:num>/<name>')
# def printing(num, name):
#     numName=""
#     for x in range (int(num)):
#         numName+=name
#     return numName

if __name__=="__main__":     
    app.run(debug=True)   

