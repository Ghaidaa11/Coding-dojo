
function hide(element) {
    element.remove();
}

var tartlike = document.querySelector("#tarticon");
var tartlikes = document.querySelector("#tartlikevalue")
var tartlikesvalue = parseInt(tartlikes.innerText);

function likingTart() {
    tartlikesvalue++;
    tartlikes.innerText = tartlikesvalue;
}

var macaronlike = document.querySelector("#macaronicon");
var macaronlikes = document.querySelector("#macaronslikevalue")
var macaronlikesvalue = parseInt(macaronlikes.innerText);

function likingmacaron() {
    macaronlikesvalue++;
    macaronlikes.innerText = macaronlikesvalue;
}
var CBlike = document.querySelector("#CBicon");
var CBlikes = document.querySelector("#CBlikesvalue")
var CBlikesvalue = parseInt(CBlikes.innerText);

function likingCB() {
    CBlikesvalue++;
    CBlikes.innerText = CBlikesvalue;
}


var searchbtn=document.querySelector("#searchbtn");
var searchTxt=search.value;

function searchAlert(){
   alert("You are searching for: "+document.getElementById("search").value);
}
